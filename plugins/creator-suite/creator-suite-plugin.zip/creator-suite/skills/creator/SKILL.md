---
name: creator
description: Guide to the creator suite. Use when the user asks which creator skill fits a task, what the suite can do, or wants to set up the shared creator-context.md file.
---
# Creator suite guide

Two jobs: point the user at the right skill, and set up the shared context file the skills read.

## Find the skill
Match the situation, name the skill, and run it if the user agrees.

| Situation | Skill |
|---|---|
| **Writing** | |
| A topic and a blank page | `idea-interview` |
| Notes or a transcript that should be an article | `draft-shaper` |
| Writing a piece together, one section at a time | `beat-writer` |
| A course or tutorial series to plan and write | `lesson-series` |
| A site that is not being found in search | `seo-checkup` |
| **Video** | |
| Explaining a topic without appearing on camera | `explainer-video` |
| A recorded talking-head video that needs graphics | `talking-head-graphics` |
| A video that needs captions or subtitles | `caption-maker` |
| A short animated title, stat or logo sting | `motion-graphic` |
| **AI media** | |
| An image from an AI image tool | `image-prompt` |
| A clip from an AI video tool | `video-prompt` |
| A video fronted by an AI presenter | `avatar-video` |
| **Brand** | |
| A new channel, newsletter or product needing an identity | `brand-kit` |

## Chains
Each skill's output is the next one's input.
- Writing: `idea-interview` → `draft-shaper` or `beat-writer`
- Article to video: `draft-shaper` → `explainer-video` → `caption-maker`
- Explainer visuals: `explainer-video` → `image-prompt` and `video-prompt`
- Presenter video: `avatar-video` → `talking-head-graphics` → `caption-maker`
- Teaching: `lesson-series` → `explainer-video`, one lesson at a time
- Identity: `brand-kit` → `motion-graphic` and `image-prompt`

## Set up creator-context.md
The skills read one optional file, `creator-context.md`, for voice, audience, platforms, brand and tools. With it, drafts sound like the creator and fit their formats. Without it, each skill asks for what it needs.

1. Read [`creator-context.template.md`](creator-context.template.md).
2. Fill it by interview, one section at a time. Draw on the creator's published work, channel pages and documents they share before asking. Let the user skip any section.
3. Save it as `creator-context.md` in the user's working folder. Where the session has no folder, deliver it as a file and tell the user to attach it or add it to their project.

Done when every section is filled or marked skipped, and the user has confirmed the voice section by reading a sample paragraph written in it.
