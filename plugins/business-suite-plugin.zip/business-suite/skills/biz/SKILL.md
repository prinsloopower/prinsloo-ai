---
name: biz
description: Guide to the business suite. Use when the user asks which business skill fits a task, what the suite can do, or wants to set up the shared business-context.md file.
---
# Business suite guide

Two jobs: point the user at the right skill, and set up the shared context file the skills read.

## Find the skill
Match the situation, name the skill, and run it if the user agrees.

| Situation | Skill |
|---|---|
| **Email and messages** | |
| A senior leader must decide, approve or unblock | `executive-email` |
| Replying to a customer, or telling customers news | `customer-email` |
| A message where the relationship is at stake | `difficult-message` |
| Telling staff about a change | `internal-announcement` |
| An unread queue to get through | `inbox-triage` |
| A long thread to catch up on | `thread-digest` |
| Things gone quiet, promises outstanding | `follow-up-sweep` |
| **Meetings** | |
| Planning a meeting | `meeting-agenda` |
| Ten minutes before a meeting | `meeting-prep` |
| A transcript or scribbles after one | `meeting-notes` |
| A recurring 1:1 | `one-on-one` |
| **Reports and documents** | |
| Leadership or board update | `executive-report` |
| Weekly project status | `status-update` |
| A choice between approaches | `decision-memo` |
| A request for money or people | `business-case` |
| A process only one person knows | `sop-writer` |
| A presentation to structure | `deck-storyline` |
| A document that must look official | `branded-document` |
| **Research and analysis** | |
| A rival to understand | `competitor-research` |
| A rep facing that rival | `battlecard` |
| A market to size up | `market-brief` |
| A customer or prospect to understand | `account-brief` |
| Vendors or tools to choose between | `vendor-scorecard` |
| A spreadsheet to make sense of | `data-readout` |
| A pile of comments or tickets | `feedback-themes` |
| **Customers and revenue** | |
| Where a customer is underserved | `customer-gap-analysis` |
| A customer business review | `qbr-prep` |
| A proposal or statement of work | `proposal-writer` |
| An RFP or security questionnaire | `rfp-response` |
| **Goals and people** | |
| What to measure | `kpi-builder` |
| Quarterly goals | `okr-draft` |
| Review season | `performance-review` |
| Opening a role | `job-description` |
| Interviewing for it | `interview-kit` |
| A new hire arriving | `onboarding-plan` |
| **Planning and operations** | |
| Starting a project | `project-plan` |
| What could go wrong | `risk-register` |
| What did go wrong | `post-mortem` |
| The week ahead | `weekly-plan` |
| Actuals against budget | `variance-commentary` |
| **Files and admin** | |
| A junk-drawer folder | `folder-cleanup` |
| An agreement to sign | `contract-brief` |
| Receipts after a trip | `expense-prep` |
| What to automate next | `task-audit` |

## Chains
Each skill's output is the next one's input.
- Competitors: `competitor-research` → `battlecard`
- Accounts: `account-brief` → `customer-gap-analysis` → `qbr-prep`
- Meetings: `meeting-agenda` → `meeting-prep` → `meeting-notes`
- Hiring: `job-description` → `interview-kit` → `onboarding-plan`
- Goals: `okr-draft` → `kpi-builder` → `status-update`
- Projects: `project-plan` → `risk-register` → `status-update` → `post-mortem`
- Any finished document → `branded-document`

## Set up business-context.md
The skills read one optional file, `business-context.md`, for voice, brand, products, customers and competitors. With it, drafts sound like the organization. Without it, each skill asks for what it needs.

1. Read [`business-context.template.md`](business-context.template.md).
2. Fill it by interview, one section at a time. Draw on connected tools, the organization's website and documents the user shares before asking. Let the user skip any section.
3. Save it as `business-context.md` in the user's working folder. Where the session has no folder, deliver it as a file and tell the user to attach it or add it to their project.

Done when every section is filled or marked skipped, and the user has confirmed the voice section by reading a sample paragraph written in it.
